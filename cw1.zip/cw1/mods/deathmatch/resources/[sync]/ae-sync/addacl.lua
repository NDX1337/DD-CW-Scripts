function handleAddACL(playerSource, cmd, playerName, ...)
    local targetPlayer = findPlayerByName(playerName) 
    if not targetPlayer then
        outputChatBox("This player is not in the server", playerSource)
        return
    end
    local playerName = getPlayerName(targetPlayer)    
    local myTable = {...}
    local groupname = table.concat(myTable, " ")
    if groupname == "smod" then
        groupname = "SuperModerator"
    elseif groupname == "hadmin" then
        groupname = "HeadAdmin"
    end
    local myGroup = false
    for k, v in ipairs(aclGroupList()) do
        if aclGroupGetName(v):lower() == groupname:lower() then
            myGroup = v
            groupname = aclGroupGetName(v)
            break
        end
    end
    if not myGroup then
        return outputChatBox("Couldn't find a group with the name '"..groupname.."'", playerSource)
    end
    local accName = getAccountName(getPlayerAccount(playerSource)) 
    local accToAdd = getAccountName(getPlayerAccount(targetPlayer))
    if isObjectInACLGroup("user."..accName, aclGetGroup("HeadAdmin")) or isObjectInACLGroup("user."..accName, aclGetGroup("Founder")) then
        if ( ((groupname ~= "Founder" and groupname ~= "HeadAdmin" and groupname ~= "Admin" and groupname ~= "+AE" and groupname ~= "Developer") or (isObjectInACLGroup("user."..accName, aclGetGroup("HeadAdmin"))) and groupname ~= "Founder" and groupname ~= "Developer") or isObjectInACLGroup("user."..accName, aclGetGroup("Developer")) or isObjectInACLGroup("user."..accName, aclGetGroup("Founder")) ) then
            if not isGuestAccount (getPlayerAccount(targetPlayer)) then		
                aclGroupAddObject(myGroup, "user."..accToAdd)
                local thePlayer = getAccountPlayer (getAccount(accToAdd))
                outputChatBox("You've given '"..playerName.."' #00ff00"..aclGroupGetName(myGroup).." #ffffffsuccesfully!", playerSource,255,255,255,true)
                outputChatBox("You've been given #00ff00"..aclGroupGetName(myGroup).." #ffffffrights!", targetPlayer,255,255,255,true)		
            else
                outputChatBox("This nibba is not logged in.", playerSource)	
            end
        else
            outputChatBox("You don't have access to do that!", playerSource)
        end
    end 
end
addCommandHandler("addacl", handleAddACL)

function handleDelACL(playerSource, cmd, playerName, ...)
    local targetPlayer = findPlayerByName(playerName) 
    if not targetPlayer then
        outputChatBox("This player is not in the server", playerSource)
        return
    end
    local playerName = getPlayerName(targetPlayer)    
    local myTable = {...}
    local groupname = table.concat(myTable, " ")
    if groupname == "smod" then
        groupname = "SuperModerator"
    elseif groupname == "hadmin" then
        groupname = "HeadAdmin"
    end
    local myGroup = false
    for k, v in ipairs(aclGroupList()) do
        if aclGroupGetName(v):lower() == groupname:lower() then
            myGroup = v
            groupname = aclGroupGetName(v)
            break
        end
    end
    if not myGroup then
        return outputChatBox("Couldn't find a group with the name '"..groupname.."'", playerSource)
    end
    local accName = getAccountName(getPlayerAccount(playerSource)) 
    local accToAdd = getAccountName(getPlayerAccount(targetPlayer)) 
    if isObjectInACLGroup("user."..accName, aclGetGroup("HeadAdmin")) or isObjectInACLGroup("user."..accName, aclGetGroup("Founder")) then
        if ( ((groupname ~= "Founder" and groupname ~= "HeadAdmin" and groupname ~= "Admin" and groupname ~= "+AE" and groupname ~= "Developer") or (isObjectInACLGroup("user."..accName, aclGetGroup("HeadAdmin"))) and groupname ~= "Founder" and groupname ~= "Developer") or isObjectInACLGroup("user."..accName, aclGetGroup("Developer")) or isObjectInACLGroup("user."..accName, aclGetGroup("Founder")) ) then
            if not isGuestAccount (getPlayerAccount(targetPlayer)) then		
                aclGroupRemoveObject(myGroup, "user."..accToAdd)
                local thePlayer = getAccountPlayer (getAccount(accToAdd))
                outputChatBox("You've removed '"..playerName.."' #00ff00"..aclGroupGetName(myGroup).." #ffffffsuccesfully!", playerSource,255,255,255,true)
                outputChatBox("Your #00ff00"..aclGroupGetName(myGroup).."#ffffff was removed!", targetPlayer,255,255,255,true)		
            else
                outputChatBox("This nibba is not logged in.", playerSource)	
            end
        else
            outputChatBox("You don't have access to do that!", playerSource)
        end
    end 
end
addCommandHandler("delacl", handleDelACL)