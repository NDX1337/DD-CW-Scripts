local totalServers = 10
addEventHandler("onClientResourceStart", resourceRoot, function()
    triggerServerEvent("onClientAskForServerNumber", resourceRoot)
    GUIEditor = {
        button = {},
        window = {},
        label = {players = {}, cwStatus = {}}
    }
    GUIEditor.window[1] = guiCreateWindow(338, 08, 586, 727, "Servers Panel", false)
    guiWindowSetSizable(GUIEditor.window[1], false)
    GUIEditor.label[1] = guiCreateLabel(62, 38, 176, 25, "Server", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label[1], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label[1], "center")
    GUIEditor.label[2] = guiCreateLabel(279, 41, 122, 20, "Players: Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label[2], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label[2], "center")
    GUIEditor.label[9] = guiCreateLabel(401, 41, 165, 24, "ClanWar Status", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label[9], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label[9], "center")
    GUIEditor.button[1] = guiCreateButton(34, 77, 227, 53, "Connect to Server 1", false, GUIEditor.window[1])
    GUIEditor.button[2] = guiCreateButton(34, 144, 227, 53, "Connect to Server 2", false, GUIEditor.window[1])
    GUIEditor.button[3] = guiCreateButton(34, 212, 227, 53, "Connect to Server 3", false, GUIEditor.window[1])
    GUIEditor.button[4] = guiCreateButton(34, 275, 227, 53, "Connect to Server 4", false, GUIEditor.window[1])
    GUIEditor.button[5] = guiCreateButton(34, 338, 227, 53, "Connect to Server 5", false, GUIEditor.window[1])
    GUIEditor.button[6] = guiCreateButton(34, 401, 227, 53, "Connect to Server 6", false, GUIEditor.window[1])
    GUIEditor.button[7] = guiCreateButton(34, 464, 227, 53, "Connect to Server 7", false, GUIEditor.window[1])
    GUIEditor.button[8] = guiCreateButton(34, 527, 227, 53, "Connect to Server 8", false, GUIEditor.window[1])
    GUIEditor.button[9] = guiCreateButton(34, 590, 227, 53, "Connect to Server 9", false, GUIEditor.window[1])
    GUIEditor.button[10] = guiCreateButton(34, 653, 227, 53, "Connect to Server 10", false, GUIEditor.window[1])
    GUIEditor.label.players[1] = guiCreateLabel(295, 93, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[1], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[1], "center")
    GUIEditor.label.players[2] = guiCreateLabel(295, 160, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[2], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[2], "center")
    GUIEditor.label.players[3] = guiCreateLabel(295, 228, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[3], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[3], "center")
    GUIEditor.label.players[4] = guiCreateLabel(295, 292, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[4], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[4], "center")
    GUIEditor.label.players[5] = guiCreateLabel(295, 356, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[5], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[5], "center")
    GUIEditor.label.players[6] = guiCreateLabel(295, 418, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[6], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[6], "center")
    GUIEditor.label.players[7] = guiCreateLabel(295, 480, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[7], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[7], "center")
    GUIEditor.label.players[8] = guiCreateLabel(295, 542, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[8], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[8], "center")
    GUIEditor.label.players[9] = guiCreateLabel(295, 604, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[9], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[9], "center")
    GUIEditor.label.players[10] = guiCreateLabel(295, 666, 80, 21, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.players[10], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.players[10], "center")
    GUIEditor.label.cwStatus[1] = guiCreateLabel(401, 86, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[1], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[1], "center")
    GUIEditor.label.cwStatus[2] = guiCreateLabel(401, 142, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[2], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[2], "center")
    GUIEditor.label.cwStatus[3] = guiCreateLabel(401, 213, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[3], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[3], "center")
    GUIEditor.label.cwStatus[4] = guiCreateLabel(401, 277, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[4], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[4], "center")
    GUIEditor.label.cwStatus[5] = guiCreateLabel(401, 338, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[5], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[5], "center")
    GUIEditor.label.cwStatus[6] = guiCreateLabel(401, 401, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[6], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[6], "center")
    GUIEditor.label.cwStatus[7] = guiCreateLabel(401, 464, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[7], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[7], "center")
    GUIEditor.label.cwStatus[8] = guiCreateLabel(401, 527, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[8], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[8], "center")
    GUIEditor.label.cwStatus[9] = guiCreateLabel(401, 590, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[9], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[9], "center")
    GUIEditor.label.cwStatus[10] = guiCreateLabel(401, 653, 172, 46, "Loading...", false, GUIEditor.window[1])
    guiLabelSetHorizontalAlign(GUIEditor.label.cwStatus[10], "center", false)
    guiLabelSetVerticalAlign(GUIEditor.label.cwStatus[10], "center")
    guiSetVisible(GUIEditor.window[1], false)
    for i = 1, totalServers do
        addEventHandler("onClientGUIClick", GUIEditor.button[i], function() triggerServerEvent("onPlayerClickConnect", resourceRoot, i) end)
    end
end)

bindKey("F6", "down", function()
    guiSetVisible(GUIEditor.window[1], not guiGetVisible(GUIEditor.window[1]))
    showCursor(guiGetVisible(GUIEditor.window[1]))
    if guiGetVisible(GUIEditor.window[1]) then
        triggerServerEvent("onClientOpenPanel", resourceRoot)
    else
        triggerServerEvent("onClientClosePanel", resourceRoot)
        guiSetText(GUIEditor.label[2], "Players: Loading...")
        for i = 1, totalServers do
            guiSetText(GUIEditor.label.players[i], "Loading...")
            guiSetText(GUIEditor.label.cwStatus[i], "Loading...")
        end
    end
end)

function handleServerSendData(serversPlayers, cwData)
    local total = 0
    for i = 1, totalServers do
        if serversPlayers then
            total = total + serversPlayers[i]
            guiSetText(GUIEditor.label.players[i], serversPlayers[i])
        end
        if cwData then
            guiSetText(GUIEditor.label.cwStatus[i], cwDataToString(cwData[i]))
        end
    end
    if serversPlayers then
        guiSetText(GUIEditor.label[2], "Players: "..total.." total")
    end
end
addEvent("onServerSendData", true)
addEventHandler("onServerSendData", resourceRoot, handleServerSendData)

function cwDataToString(cwData)
    return cwData.status.."\n"..cwData.score.."\n"..cwData.teams
end

addEvent("onServerSendServerNumber", true)
addEventHandler("onServerSendServerNumber", resourceRoot, function(number)
    guiSetEnabled(GUIEditor.button[number], false)
end)